
    <script src="<?= base_url(); ?>public/js/bootstrap.min.js"></script>
    <script src="<?= base_url(); ?>public/js/offcanvas.js"></script>
    <script src="<?= base_url(); ?>public/js/bootstrap-4-navbar.js"></script>
      </body>
</html>
